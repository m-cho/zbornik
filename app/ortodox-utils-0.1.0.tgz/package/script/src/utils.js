"use strict";
// 'use strict'
// const moment  = require('moment');
Object.defineProperty(exports, "__esModule", { value: true });
exports.convertStringToDayNum = exports.makeJulian = void 0;
/**
 * Convert a date to a Julian Date
 * @param gregorianDate
 * @returns {Date}
 */
function makeJulian(gregorianDate) {
    const d = new Date(gregorianDate);
    d.setDate(d.getDate() - 13);
    return d;
}
exports.makeJulian = makeJulian;
;
/**
 * Converts a day of week string to a number
 * @param inputDayOfWeek {DayInAWeek}
 * @returns {number}
 */
function convertStringToDayNum(inputDayOfWeek) {
    return {
        'Sun': 0,
        'Mon': 1,
        'Tue': 2,
        'Wed': 3,
        'Thu': 4,
        'Fri': 5,
        'Sat': 6
    }[inputDayOfWeek];
}
exports.convertStringToDayNum = convertStringToDayNum;
