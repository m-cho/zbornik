import type { Calendar } from './utils.js';
export declare function getPeriodsForDate(date: string, calendar: Calendar): string[];
export declare function getWeekAfterPentecost(date: string, calendar: Calendar): {
    week: number | null;
    sundayAfterPentecost: number | null;
};
export declare function getWeekAfterPascha(date: string, calendar: Calendar): {
    week: number | null;
    sundayAfterPascha: number | null;
};
