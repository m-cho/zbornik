import type { Calendar } from "./utils.js";
/**
 * Based on the calculations of Carl Friedrich Gauss
 * Calculations in the Julian Calendar
 * getPascha(2044, 'new');
 * @param {number} year
 * @param {Calendar} cal
 * @returns {Date}
 */
export declare function getPascha(year: number, cal: Calendar): Date;
