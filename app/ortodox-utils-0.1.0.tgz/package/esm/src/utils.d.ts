export type Range = {
    start: Date;
    end: Date;
};
export type DayInAWeek = 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat' | 'Sun';
export type Direction = 'before' | 'after';
export type Calendar = 'new' | 'old';
/**
 * Convert a date to a Julian Date
 * @param gregorianDate
 * @returns {Date}
 */
export declare function makeJulian(gregorianDate: Date): Date;
/**
 * Converts a day of week string to a number
 * @param inputDayOfWeek {DayInAWeek}
 * @returns {number}
 */
export declare function convertStringToDayNum(inputDayOfWeek: DayInAWeek): number;
