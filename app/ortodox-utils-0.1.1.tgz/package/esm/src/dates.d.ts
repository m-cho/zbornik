import { type Calendar, type Range } from './utils.js';
/**
 * Generates all the feasts and fast dates for the year
 * @param {number} year
 * @param {Calendar} calendar
 * @return {Object}
 */
export declare function getForYear(year: number, calendar: Calendar): Record<string, Date | Range | (Range & {
    followingYear: Range;
} | boolean)>;
